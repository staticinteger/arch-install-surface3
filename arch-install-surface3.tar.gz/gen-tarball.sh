rm arch-install-surface3.tar.gz
tar -zcvf arch-install-surface3.tar.gz ./*
