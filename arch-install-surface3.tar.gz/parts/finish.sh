# Unmount hard drive partitions and reboot
umount -R /mnt
reboot
